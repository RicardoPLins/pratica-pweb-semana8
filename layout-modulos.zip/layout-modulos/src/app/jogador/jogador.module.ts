import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import {FormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatBadgeModule} from '@angular/material/badge';
import {FlexModule} from '@angular/flex-layout';
import {RouterLink} from '@angular/router';
import { MantemJogadorComponent } from './mantem-jogador/mantem-jogador.component';
import { ListagemJogadoresComponent } from './listagem-jogador/listagem-jogador.component';



@NgModule({
  declarations: [
    ListagemJogadoresComponent,
    MantemJogadorComponent,
    ListagemJogadoresComponent
  ],
  imports: [
    CommonModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatBadgeModule,
    FlexModule,
    RouterLink
  ],
  exports: [
    ListagemJogadoresComponent,
    MantemJogadorComponent
  ]
})
export class JogadorModule { }
