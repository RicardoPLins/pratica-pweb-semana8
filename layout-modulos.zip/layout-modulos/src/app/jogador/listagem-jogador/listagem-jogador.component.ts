import { Component } from '@angular/core';
import {Jogador} from '../../shared/modelo/jogador';
import {JOGADORES} from '../../shared/modelo/JOGADORES';

@Component({
  selector: 'app-listagem-jogador',
  templateUrl: './listagem-jogador.component.html',
  styleUrls: ['./listagem-jogador.component.css']
})
export class ListagemJogadoresComponent {

  jogadores: Jogador[] = JOGADORES;
  excluir(jogadorARemover: Jogador): void {
    const indx = this.jogadores.findIndex(jogador =>
      jogador.nome === jogadorARemover.nome);

    this.jogadores.splice(indx, 1);
  }

}
