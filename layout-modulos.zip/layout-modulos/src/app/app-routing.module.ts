import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {MantemJogadorComponent} from './jogador/mantem-jogador/mantem-jogador.component';
import {ListagemJogadoresComponent} from './jogador/listagem-jogador/listagem-jogador.component';

const routes: Routes = [
  {
    path: 'cadastrojogador',
    component: MantemJogadorComponent
  },
  {
    path: 'editajogador/:id',
    component: MantemJogadorComponent
  },
  {
    path: 'listagemjogadores',
    component: ListagemJogadoresComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
