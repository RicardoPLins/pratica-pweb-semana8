import {Jogador} from './jogador';

export const JOGADORES: Array<Jogador> = [
  {
    nome: 'Lebron James',
    numero: 6,
    time: 'LAL'
  },
  {
    nome: 'Ja Morant',
    numero: 12,
    time: 'GRI'
  },
  {
  nome: 'Stephen Curry',
  numero: 30,
  time: 'GSW'
  }
]
