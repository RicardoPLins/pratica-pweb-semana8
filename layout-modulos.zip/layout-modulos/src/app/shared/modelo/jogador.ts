export class Jogador {

  constructor(public nome = '',
              public numero?: number,
              public time: string = '') {
  }
}
